# Physics-chemistry-solution-
My physics chemistry solution for learning and solving 
